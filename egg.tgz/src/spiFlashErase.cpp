// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Erase SPI sectors\n", stdout);
  return lionss_run_workload("spiFlashErase");
}
